function calculateEMI() {
    const loanAmount = document.getElementById('loan-amount').value;
    const interestRate = document.getElementById('interest-rate').value;
    const loanTenure = document.getElementById('loan-tenure').value;

    if (loanAmount && interestRate && loanTenure) {
        const monthlyInterestRate = interestRate / (12 * 100);
        const tenureInMonths = loanTenure * 12;
        const emi = (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, tenureInMonths)) /
                    (Math.pow(1 + monthlyInterestRate, tenureInMonths) - 1);

        document.getElementById('emi-result').innerText = `Your EMI is ₹${emi.toFixed(2)}`;
    } else {
        alert('Please fill out all fields.');
    }
}

function checkCIBIL() {
    document.getElementById('cibil-result').innerText = 'Your CIBIL Score is 785 (Excellent)';
}

function manageUsers() {
    document.getElementById('user-result').innerText = 'User management feature coming soon!';
}
